---
name: check-internal-biomedical-research-memory
description: Automatically check Breadcrumbs before proposing, evaluating, or interpreting biomedical hypotheses, experiments, analyses, duplication, novelty, or follow-up research.
---

# Check Internal Biomedical Research Memory

Use the enabled `breadcrumbs` MCP connector as the organization's internal research memory. Prefer internal evidence before external context. Do not treat the database as a literature database or infer novelty from missing rows.

## Decide when to check

Check Breadcrumbs before answering a request that:

- proposes, prioritizes, or evaluates a biomedical hypothesis;
- plans an analysis or experiment;
- asks whether work is new, duplicated, previously attempted, or worth repeating;
- interprets an internal result or recommends follow-up work.

Skip the check for simple educational facts that do not propose or evaluate research.

If the connector tools are not loaded, search for the `breadcrumbs` tools, then call them. Do not stop after listing or discovering tools. If the connector is unavailable, state that the internal-memory check could not be performed.

## Read before reasoning

Use `breadcrumbs:check_duplication` for a proposed hypothesis and `breadcrumbs:recall_findings`
for broader topic, entity, or context recall. Both use the local graph matcher. Use the exact
`breadcrumbs:read` primitive when the request supplies a credible stored field/value filter.

1. Extract disease, category, gene, biomarker, phenotype, outcome, and status clues from the request.
2. Normalize obvious names to likely stored values before reading. Prefer canonical disease codes
   and gene symbols over prose names.
3. Call `breadcrumbs:check_duplication` or `breadcrumbs:recall_findings` with the research question.
   Add exact `breadcrumbs:read` calls for `disease`, `category`, `status`, `author`,
   `source_session_id`, or another supported field when the request supplies a credible value.
4. If a term has multiple scientifically plausible canonical forms, make a bounded set of
   additional reads rather than assuming the first form is correct. Usually two to four reads are
   enough; do not generate an unbounded synonym list.
5. Combine and de-duplicate results by finding `id`, then judge relevance from the complete finding
   text returned by the tool. A broad disease query may return the relevant hypothesis even when
   its wording differs from the request.
6. Do not silently skip the read because the scientific answer seems familiar.

### Find canonical terms with web search

When the request uses prose names, abbreviations, or possible aliases, use web search to identify
the canonical disease codes, gene symbols, and established synonyms before calling
`breadcrumbs:read`. Prefer authoritative public sources such as NCI, HGNC, NCBI, or disease
ontology documentation. Search again when an empty exact query may be explained by a naming
mismatch.

Keep web searches limited to public terminology. Never send internal finding text, unpublished
hypotheses, patient-level information, source-session content, researcher identities, or other
confidential organizational context to web search. Reduce the query to the isolated public term,
for example `lung adenocarcinoma canonical disease abbreviation` or `LKB1 official gene symbol`.
If a term cannot be searched without disclosing confidential context, do not search it; state the
limitation and use safe exact values already supplied by the user.

Use the retrieved aliases to make a bounded set of exact internal reads, usually two to four.
Never broaden silently: related disease subtypes are not interchangeable, and a finding from one
must not be presented as though it came from another. Gene aliases help interpret findings returned
by a disease or category read; the current exact tool does not search inside the JSON `entities`
array by individual member.

Example call:

```json
{
  "column": "disease",
  "value": "LUAD"
}
```

An empty response means only that the exact filter matched no row in the current database. Say which filter was checked. Never call that result proof of novelty.

Before presenting an empty-result conclusion, verify that obvious canonical disease codes and
aliases were tried. Report every exact `column = value` filter used, including filters that returned
zero rows. Use wording such as: `No prior work was found for the exact internal filters disease =
LUAD and disease = LUSC.`

## Summarize retrieved memory

Present internal memory before external knowledge:

1. State how many findings were returned and how directly they bear on the question.
2. Separate `confirmed`, `in-progress`, and `abandoned` findings.
3. Preserve effect sizes, confidence intervals, p-values, sample sizes, and caveats exactly as stored.
4. For abandoned findings, prominently report `reason` and `note` so failed approaches are not repeated.
5. Include `disease`, `category`, `entities`, `author`, `timestamp`, and `source_session_id` for traceability.
6. Say when a field is absent. Do not invent values, strengthen associations into causal claims, or blend separate findings.

Use this compact format for each result:

```text
[status] hypothesis_text
Effect: effect
Entities: entities
Why it matters: direct relevance to the current question
Reason/note: include for abandoned or caveated work
Source: author, timestamp, source_session_id
```

## Write reviewed findings only

Call `breadcrumbs:write_finding` only when the conversation contains a reviewed finding supported by an ingested source session. Write one finding per tool call.

Required `record` fields:

```json
{
  "category": "registered category",
  "disease": "disease code",
  "hypothesis_text": "specific testable claim or question",
  "entities": ["NORMALIZED", "ENTITY", "NAMES"],
  "effect": "verbatim result including statistics and caveats",
  "status": "confirmed | in-progress | abandoned | open",
  "author": "researcher name",
  "source_session_id": "existing ingested session id",
  "source_type": "internal | external"
}
```

Optional fields are `id`, `created_at`, `n`, `provenance`, `reason`, `note`, `markdown`, and `resources`. Omit `id` and `created_at` to let Breadcrumbs create them.

Apply these validation rules:

- Use only a registered `category` and an existing `source_session_id`.
- Use `source_type: internal` for organization-generated work; it must not include resources.
- Use `source_type: external` for published evidence and include non-empty `resources`. Each resource must have `type` set to `paper` or `database` and a `citation`; `url` is optional.
- Use `reason` for `abandoned` findings; make it concrete and actionable.
- Set `reason` to null or omit it for `confirmed` and `in-progress` findings.
- Put methodology and data origin in `provenance`.
- Put caveats and future-research guidance in `note`.
- Never fabricate a required field. Ask the user for missing information instead.

After a successful write, report the stored ID and briefly repeat exactly what was persisted.
